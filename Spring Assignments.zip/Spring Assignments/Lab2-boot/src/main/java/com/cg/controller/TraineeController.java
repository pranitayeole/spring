package com.cg.controller;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Trainee;
import com.cg.service.TraineeService;


@RestController
public class TraineeController {


	@Autowired
	private TraineeService service;
	
	@GetMapping("/all")
	public Iterable<Trainee> getAll() {
		return service.getAll();
	}
	
	@PostMapping(path = "/add", consumes = "application/json")
	public String saveTrainee(@RequestBody Trainee t) {
		service.saveTrainee(t);
		return "Trainee Saved";
	}
	
	@GetMapping(path = "/trainee/{id}")
	public ResponseEntity<Trainee> getTrainee(@PathVariable("id") int id) {
		try {
			Trainee t = service.getTrainee(id);
			return new ResponseEntity<Trainee>(t, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity("No Trainee found", HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping(path = "/update/{id}", consumes = "application/json")
	public Trainee updateTrainee(@PathVariable("id") int id, @RequestBody Trainee t) {
		return service.updateTrainee(t, id);

	}

	@DeleteMapping(path = "/delete/{id}")
	public String deleteTrainee(@PathVariable("id") int id) {
		return service.deleteTrainee(id);
	}

}
