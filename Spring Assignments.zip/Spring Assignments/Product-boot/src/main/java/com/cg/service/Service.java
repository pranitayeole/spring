package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@SpringBootApplication
@EntityScan("com.cg.entity")
@Transactional
public class Service implements ServiceI {

	@Autowired
	private ProductRepo repo;
	
	@Override
	public Product get(int id) {
		Product p = repo.findById(id).get();
		return p;
	}

	@Override
	public List<Product> getAll() {
		return (List<Product>) repo.findAll();
	
	}

	@Override
	public void saveProduct(Product p) {
		repo.save(p);
		
	}

	@Override
	public String delete(int id) {
		repo.deleteById(id);
		return "Product deleted";
	}

	@Override
	public void updateProduct(Product p) {
		repo.save(p);
		
	}

}
