package com.cg.service;

import java.util.List;

import com.cg.entity.Product;

public interface ServiceI {
	
	public Product get(int id);
	
	public List<Product> getAll();
	
	public void saveProduct(Product p);
	
	public String delete(int id);
	
	public void updateProduct(Product p);

}
