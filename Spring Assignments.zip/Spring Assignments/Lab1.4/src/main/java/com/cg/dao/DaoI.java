package com.cg.dao;

import com.cg.bean.Employee;

public interface DaoI {

	public void addAll();
	public Employee findEmployee(int id);
	
}
