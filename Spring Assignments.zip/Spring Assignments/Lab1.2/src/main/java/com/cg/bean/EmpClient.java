package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmpClient {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("details.xml");
		Employee emp = (Employee) ctx.getBean("employee");
		
		System.out.println("Employee Details");
		System.out.println("-------------------------");
		System.out.println(emp);
	}
}